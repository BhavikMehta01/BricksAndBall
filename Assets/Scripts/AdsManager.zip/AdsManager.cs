﻿using System;
using UnityEngine;
using GoogleMobileAds.Api;

public class AdsManager : MonoBehaviour
{
    private InterstitialAd interstitial_Ad;
    private RewardedAd rewarded_Ad;
    private BannerView banner_Ad;

    private string interstitial_Ad_ID;
    private string rewardedAd_ID;
    private string bannerAd_ID;

    void Start()
    {
        interstitial_Ad_ID = "ca-app-pub-3940256099942544/1033173712";
        rewardedAd_ID = "ca-app-pub-3940256099942544/5224354917";
        bannerAd_ID = "ca-app-pub-3940256099942544/6300978111";

        MobileAds.Initialize(initStatus => { });

        RequestInterstitial();
        RequestRewardedVideo();
      //  RequestBanner();

    }
    private void RequestBanner()
    {
        banner_Ad = new BannerView(bannerAd_ID, AdSize.Banner, AdPosition.Top);
        AdRequest request = new AdRequest.Builder().Build();
        this.banner_Ad.LoadAd(request);
    }


    private void RequestInterstitial()
    {
        interstitial_Ad = new InterstitialAd(interstitial_Ad_ID);
        interstitial_Ad.OnAdLoaded += HandleOnAdLoaded;
        AdRequest request = new AdRequest.Builder().Build();
        interstitial_Ad.LoadAd(request);
    }

    private void RequestRewardedVideo()
    {
        rewarded_Ad = new RewardedAd(rewardedAd_ID);
        rewarded_Ad.OnUserEarnedReward += HandleUserEarnedReward;
        rewarded_Ad.OnAdClosed += HandleRewardedAdClosed;
        rewarded_Ad.OnAdFailedToShow += HandleRewardedAdFailedToShow;
        AdRequest request = new AdRequest.Builder().Build();
        rewarded_Ad.LoadAd(request);
    }

    public void ShowInterstitial()
    {
        if (interstitial_Ad.IsLoaded())
        {
            interstitial_Ad.Show();
            RequestInterstitial();
        }

    }

    public void ShowRewardedVideo()
    {
        if (rewarded_Ad.IsLoaded())
        {
            rewarded_Ad.Show();
        }
    }

    public void HandleOnAdLoaded(object sender, EventArgs args)
    {

    }

    public void HandleRewardedAdFailedToShow(object sender, AdErrorEventArgs args)
    {
        RequestRewardedVideo();
    }

    public void HandleRewardedAdClosed(object sender, EventArgs args)
    {
        RequestRewardedVideo();
    }

    public void HandleUserEarnedReward(object sender, Reward args)
    {
        RequestRewardedVideo();
    }
}
